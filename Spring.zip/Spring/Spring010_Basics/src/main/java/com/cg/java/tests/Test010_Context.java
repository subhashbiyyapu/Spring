package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmployeeServices;
import com.cg.java.services.SalaryServices;
/*
 * the bean and bean tags come from spring-beans.xsd
 * the bean tag takes atleast  two attributes
 *             The class attribute:REpresents fully qualified name of a class
 *             The id attribute :TO uniquely identify bean 
 * The ClassPathXmlContext 
 *           is a spring container implementing interface ApplicationContext
 *  On creation of        ClassPathXmlContext
 *               Refers the configuration file and creates every bean declared there
 *                Beans are of two types:Singleton ,Prototype
 *                Singleton:Object created only once.By default it is singleton
 *                Prototype:Object created as and when required
 *                
 *         Eager bean creation:
 *         all beans are created at the time of context creation     
 *         
 *         lazy creation:
 *                  in prototype    
 *         
 *         lazy-init:     makes the singleton object creation lately
 *                  
 *             
 */
public class Test010_Context {
public static void main(String args[])
{
	//1.Create Spring Context,Spring Container
	//BeanFacory factory =new XmlBeanFactory();
	//ApplicationContext is modified version of BeanFactory
	//From Spring 4.3 onwards ,BeanFactory is deprecated
	ApplicationContext ctx=new ClassPathXmlApplicationContext("SpringCore.xml");
	System.out.println("***************************");
	EmployeeServices services1=(EmployeeServices)ctx.getBean("empServices");
	EmployeeServices services2=(EmployeeServices)ctx.getBean("empServices");
	
	System.out.println(services1.getMessages());
	System.out.println(services2.getMessages());
	System.out.println(services1.getAddress());
	System.out.println(services2.getAddress());
	/*SalaryServices services3=(SalaryServices)ctx.getBean("salServices");
	System.out.println(services3.calcSalary());
	*/
	
	
}
}
