package com.cg.java.services;

public class SalaryServices {
	
	public SalaryServices()
	{
		System.out.println("object salery services created");
	}
	public String calcSalary()
	{
		return "salary calculated";
	}

}
