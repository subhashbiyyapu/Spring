package com.cg.java.tests;

import org.springframework.context.ApplicationContext;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.core.dao.EmpDao;



public class Test050 {

	public static void main(String[] args) {
		ConfigurableApplicationContext ctx=new ClassPathXmlApplicationContext("SpringCore.xml");
	System.out.println("**********************************");
		
		
		EmpDao dao=ctx.getBean(EmpDao.class);
	
	
	}
	
}
