package com.cg.core.dao;

import java.util.List;



public interface EmpDao  {


}
