package com.cg.core.dao;

import java.util.ArrayList;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;
@Repository("empDao")
public class EmpDaoImpl    implements EmpDao  {
	@Value("10")
	private int value;
	@Autowired
	private SalaryDao  dao;
	
	public EmpDaoImpl (){
		System.out.println("Emp bean Created");
		
	}


	@Override
	public String toString() {
		return "EmpDaoImpl [value=" + value + "]";
	}
	
}