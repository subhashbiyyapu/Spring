package com.cg.core.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
/*
 * Using connection pool is always a best practice instead of managing single connect
 * Spring support javax.sql.DataSource is manager for the connection pool
 * A dataSourceManager in Spring gives ready connection pool and DataSource
 */

@Repository
public class EmpDaoImpl implements EmpDao {
	@PersistenceContext
	private EntityManager manager;

	@Override
	public List<Emp> getEmpList() throws EmpException {
		List<Emp> empList = null;
		String query = "from Emp ";// the Emp is an entity
		try {
			Query qry = manager.createQuery(query, Emp.class);
			empList = qry.getResultList();
		} catch (Exception e) {// Exception chaining
			throw new EmpException("error while procurring data", e);

		}

		return empList;
	}

}
