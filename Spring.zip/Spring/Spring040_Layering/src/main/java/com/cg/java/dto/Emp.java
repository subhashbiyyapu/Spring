package com.cg.java.dto;

public class Emp {
	
	private  int empNo;
	private String empName;
	private float empSal;
	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empName=" + empName + ", empSal=" + empSal + "]";
	}
	public Emp() {
	
	}
	public Emp(int empNo, String empName, float empSal) {
		super();
		this.empNo = empNo;
		this.empName = empName;
		this.empSal = empSal;
	}
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	

}
