package com.cg.java.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.java.dto.Emp;
import com.cg.java.exceptions.EmpException;


public class EmpDaoImpl    implements EmpDao  {
	
	
	public EmpDaoImpl (){
		
	}
	public List<Emp> getEmpList() throws EmpException
	{
		List<Emp> empList=new ArrayList<Emp>();
		empList.add(new Emp(100,"subhash",100000));
		empList.add(new Emp(101,"mahesh",200000));
		empList.add(new Emp(102,"naresh",300000));
	
		return empList;
		
	}

}
