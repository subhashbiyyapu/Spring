package com.cg.java.services;

import java.util.List;

import com.cg.java.dao.EmpDao;
import com.cg.java.dto.Emp;
import com.cg.java.exceptions.EmpException;

public interface EmpService {
	List<Emp> getEmpList()  throws EmpException;
	 void setDao(EmpDao dao);

}
