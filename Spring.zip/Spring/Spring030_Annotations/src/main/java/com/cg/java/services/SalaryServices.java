package com.cg.java.services;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("salServices")
public class SalaryServices {
	
	public SalaryServices()
	{
		System.out.println("object salery services created");
	}
	public String calcSalary()
	{
		return "salary calculated";
	}

}
