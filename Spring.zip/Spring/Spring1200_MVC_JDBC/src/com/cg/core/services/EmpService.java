package com.cg.core.services;

import java.util.List;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

public interface EmpService {
	
	String authenticate(String username,String password);
	public List<Emp> getEmpList() throws EmpException;

}
