package com.cg.core.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;
/*
 * Using connection pool is always a best practice instead of managing single connect
 * Spring support javax.sql.DataSource is manager for the connection pool
 * A dataSourceManager in Spring gives ready connection pool and DataSource
 */


@Repository
public class EmpDaoImpl implements EmpDao {
	@Autowired
	 private DataSource dataSource;

	@Override
	public List<Emp> getEmpList() throws EmpException {
		
		Connection connect=null;
		Statement stmt=null;
		ResultSet rs=null;
		List<Emp> empList=new ArrayList<Emp>();
String query="SELECT empId,firstname ,salary from emp_table";
try
{
connect=dataSource.getConnection();
stmt=connect.createStatement();
rs=stmt.executeQuery(query);
while(rs.next())
{
	int empNo=rs.getInt("empId");
	String name=rs.getString(2);
	float salary=rs.getFloat(3);
	Emp emp=new Emp(empNo,name,salary);
	empList.add(emp);
}
	
		}
		catch(SQLException e)
		{//Exception chaining
			throw new EmpException("error while procurring data",e);
			
		}
finally
{
	try
	{
	if(rs!=null)
	{
		rs.close();
	}
	if(stmt!=null)
	{
		stmt.close();
	}
	if(connect!=null)
	{
		connect.close();//this close does not close the connection ,this returns back to connection pool
	}
	}
	catch(SQLException e)
	{
		throw new EmpException("error while closing the connection");
	}
}
		
		
		return empList;
	}

}
