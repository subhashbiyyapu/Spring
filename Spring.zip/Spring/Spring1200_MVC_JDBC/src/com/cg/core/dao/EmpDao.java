package com.cg.core.dao;

import java.util.List;

import com.cg.core.dto.Emp;
import com.cg.core.exceptions.EmpException;

public interface EmpDao {
	
	public List<Emp> getEmpList() throws EmpException;

}
