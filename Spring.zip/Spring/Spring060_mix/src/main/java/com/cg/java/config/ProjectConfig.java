package com.cg.java.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.services.EmpService;
import com.cg.java.services.EmpServiceImpl;

/*
 * @Configuration:
 * it is class level annotation 
 * Declares a class as Configuration class
 * 
 * 
 * @Bean
 * Method level
 * Declares  a method as factory method
 * factory method:
 * a method responsible  for  creating,initializing a object is called factory method
 * 
 * 
 * The @Lazy and @Scope  are also allowed on factory methods 
 * 
 * Three approaches for bean configuration:
 *     1.XML approach
 *            Bean is declared in Spring XML Configuration
 *            Do not declare bean with annotation, Component-scan and factory method 
 *     2.  Annotation(@component ,@Repository,@Service)
 *           Mention Component-scan either in XML or in java config
 *           Donot declare bean in XML And factory Method
 *     3.Factory method:
 *         Create a factory method in java Config class
 *          Donot annotate bean and thus no Component-scan
 *          Donot declare bean with<bean> in XMl Configuration
 *               
 *             
 *           
 *     
 *          
 *            
 * 
 */

@Configuration
@ComponentScan("com.cg.java.services")
@ImportResource("SpringCore.xml")

public class ProjectConfig {

	@Bean("empDao")

	public EmpDao getEmpDao()
	{System.out.println("object created");
		return new EmpDaoImpl();	
	}
	
	
			
			
	
	
	
	
}
