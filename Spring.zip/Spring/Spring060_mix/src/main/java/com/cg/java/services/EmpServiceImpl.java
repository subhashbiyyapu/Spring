package com.cg.java.services;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.java.dao.EmpDao;
import com.cg.java.dao.EmpDaoImpl;
import com.cg.java.dao.SalaryDao;
import com.cg.java.dto.Emp;
import com.cg.java.dto.EmpSal;
import com.cg.java.exceptions.EmpException;
@Service("empService")
public class EmpServiceImpl implements EmpService {
	@Autowired
	private EmpDao dao;
	
	@Autowired
	private SalaryDao salDao;
	
	public List<EmpSal> getEmpSalList() throws EmpException
	{
		return salDao.getEmpSalList();
	}
	
	
	public EmpDao getDao() {
		return dao;
	}

	public void setDao(EmpDao dao) {
		this.dao = dao;
	}

	public List<Emp> getEmpList()  throws EmpException
	{
	return dao.getEmpList();
	}

}
