package com.cg.web.boot;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;
//it automatically component scans under boot folder
@SpringBootApplication
public class SpringBootStrap {

	public static void main(String[] args) {
	
		SpringApplication.run(SpringBootStrap.class,args);

	}

}
