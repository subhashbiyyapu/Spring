package com.cg.java.services;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/*
 * afterPropertiesSet  is called after the properties are set ie:; all setters method
 * 
 * 
 * DisposableBean interface implements destroy ,method which is called while 
 * bean is removed from Spring Context
 * PostConstruct and PreDestroy are java  features for InitializingBean,DisposableBean
 * where as InitializingBean,DisposableBean are spring featuers
 */
@Component("empServices")
public class EmployeeServices //implements InitializingBean,DisposableBean
{
	@Value("Capgemini,pune")
	private String companyName;
	
	private String address;
	@Value("80000")
	private  float yearlypackage;

	private SalaryServices services;
	
	
	

	public EmployeeServices(String companyName, String address) {
		System.out.println("in 2 param constructor");
		this.companyName = companyName;
		this.address = address;
	}

	
	public EmployeeServices(String companyName, String address,float  yearlypackage) {
		System.out.println("in  3 param constructor");
		this.companyName = companyName;
		this.address = address;
		this.yearlypackage=yearlypackage;
		
	}

	public  EmployeeServices()
	{
		System.out.println("EmpService Object created");
	}
	
	public String getMessages()
	{
		System.out.println(services.calcSalary()  );
		return "Welcome to Spring Training"+companyName;
		
	}
	//Properties
	public String getCompanyName() {//companyName
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getAddress() {
		return address;
	}
	@Value("talwade")
	public void setAddress(String address) {
		this.address = address;
	}

	public SalaryServices getServices() {
		return services;
	}
	@Autowired
	//By type:    Find the bean as per the type and not on "id"
	//Byname : find bean on basis of Id
	@Qualifier("salServices")
	public void setServices(SalaryServices services) {//services
		System.out.println("Setter method");
		this.services = services;
	}

@PostConstruct
	public void afterPropertiesSet() throws Exception {
		
	System.out.println("in properiesSet()");
	
	}

@PreDestroy
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("destroyed");
		
	}
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();
		System.out.println("finalize");
	}

	
	
}
