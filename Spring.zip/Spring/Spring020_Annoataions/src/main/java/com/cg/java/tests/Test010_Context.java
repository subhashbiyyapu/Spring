package com.cg.java.tests;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.java.services.EmployeeServices;
import com.cg.java.services.SalaryServices;
/*
 * bean declaration can be done using @Component
 * the initial value can be hard coded using @Value
 * There are 3 types of injection
 * The Field Injection :Give @Autowired to field
 * The constructor injection :Give @Autowired to constructor
 * The setter Injection :Give @Autowired to Setter method
 *        
 */
public class Test010_Context {
public static void main(String args[])
{
	//1.Create Spring Context,Spring Container
	//BeanFacory factory =new XmlBeanFactory();
	//ApplicationContext is modified version of BeanFactory
	//From Spring 4.3 onwards ,BeanFactory is deprecated
	ApplicationContext ctx=new ClassPathXmlApplicationContext("SpringCore.xml");
	System.out.println("***************************");
	EmployeeServices services1=(EmployeeServices)ctx.getBean("empServices");
	EmployeeServices services2=(EmployeeServices)ctx.getBean("empServices");
	
	System.out.println(services1.getMessages());
	System.out.println(services2.getMessages());
	System.out.println(services1.getAddress());
	System.out.println(services2.getAddress());
	

	SalaryServices services3=(SalaryServices)ctx.getBean("salServices");
	System.out.println(services3.calcSalary());
	
	ConfigurableApplicationContext cctx=(ConfigurableApplicationContext) ctx;
	cctx.close();
	
}
}
